library(testthat)
library(rdiversity)

test_check("rdiversity")

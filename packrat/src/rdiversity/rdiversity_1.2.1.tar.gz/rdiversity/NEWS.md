rdiversity v1.0 (Release date: 2016-06-14)
==============

Changes:

* Initial submission to CRAN


rdiversity v1.1 (Release date: 2018-05-08)
==============

Changes:

* Removed redundant argument chainsaw(depth); Renamed chainsaw(interval) to chainsaw(depth); Minor edits to documentation.


rdiversity v1.2 (Release date: 2018-06-12)
==============

Changes:

*  Allow partition types to be input in a random order, or with missing or additional types; Tests added for new functionality.


rdiversity v1.2.1 (Release date: 2018-06-19)
================

Changes:

*  Fix problems that occur when user doesn't have row names in the partition object
*  Update citation
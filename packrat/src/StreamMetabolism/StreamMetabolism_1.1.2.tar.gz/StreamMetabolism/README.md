# StreamMetabolism
R package for calculating single station stream metabolism from diurnal oxygen curves

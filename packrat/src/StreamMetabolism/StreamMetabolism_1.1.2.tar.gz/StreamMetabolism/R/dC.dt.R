`dC.dt` <-
function(x){diff(x, na.pad=TRUE)}


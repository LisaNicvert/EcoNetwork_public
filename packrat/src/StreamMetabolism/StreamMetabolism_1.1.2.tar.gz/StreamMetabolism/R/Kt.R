`Kt` <-
function(K, temp){
	K*(1.0241^(temp-20))
}


#include <RcppArmadillo.h>
using namespace arma;

RcppExport
SEXP split(SEXP vars);

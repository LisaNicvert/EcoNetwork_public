
#define TOL_P 1e-1
#define TOL_M 1e-4
#define TOL_F 1e-1
#define TOL_EM 1e-5
#define BFGS_ITER_MIN 2
#define BFGS_ITER_MAX 500
#define LINE_SEARCH_ITER_MAX 40

//#define DEBUG_EM
//#define DEBUG_E
//#define DEBUG_M

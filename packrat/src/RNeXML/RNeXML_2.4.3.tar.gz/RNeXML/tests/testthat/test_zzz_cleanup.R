context("testthat cleanup")
unlink("ex.tre")
unlink("ex.xml")
unlink("tmp.xml")
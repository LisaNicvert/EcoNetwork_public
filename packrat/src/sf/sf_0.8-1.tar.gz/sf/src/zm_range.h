Rcpp::NumericVector CPL_get_zm_range(Rcpp::List sf, int depth);

Rcpp::NumericVector CPL_get_z_range(Rcpp::List sf, int depth);

Rcpp::NumericVector CPL_get_m_range(Rcpp::List sf, int depth);

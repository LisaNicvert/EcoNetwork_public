library(testthat)
suppressPackageStartupMessages(library(sf))

test_check("sf")

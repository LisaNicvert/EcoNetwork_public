library(testthat)
library(PLNmodels)

test_check("PLNmodels")
